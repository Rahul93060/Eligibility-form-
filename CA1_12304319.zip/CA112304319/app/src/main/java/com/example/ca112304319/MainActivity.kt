package com.example.ca112304319

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        val img = findViewById<ImageView>(R.id.IV1)
        val etName = findViewById<EditText>(R.id.et1)
        val etRegNo = findViewById<EditText>(R.id.et2)
        val etTotalClasses = findViewById<EditText>(R.id.et3)
        val etAttended = findViewById<EditText>(R.id.et4)
        val btnCheck = findViewById<Button>(R.id.btn)


        btnCheck.setOnClickListener {

            val name = etName.text.toString().trim()
            val regNo = etRegNo.text.toString().trim()
            val total = etTotalClasses.text.toString().trim()
            val attended = etAttended.text.toString().trim()

            val totalClasses = total.toInt()
            val attendedValue = attended.toInt()

            val attendancePercent = (attendedValue * 100) / totalClasses


            if (attendancePercent >= 75) {
                Toast.makeText(this, " Eligible", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "is NOT Eligible", Toast.LENGTH_SHORT).show()
            }
        }
    }
}



